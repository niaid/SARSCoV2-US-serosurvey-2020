#' @title Combined NHIS2018 and randomly selected brfss data of 2000 observations
#'
#' @description A data set with common varaibles for propensity analysis.
#'
#' @format A data frame with about 33,997 rows and 38 variables:


"exampleData"
