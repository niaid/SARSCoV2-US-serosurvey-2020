#'@title Propensity-based pseudoweighted population mean 
#'@description Propensity-based pseudoweighted population mean with weights estimated by the inverse of inclusion probabilities weighting method and kernel smooth weighting methods, denoted by ALP and KW
#'
#'@import stats survey mvtnorm Hmisc dplyr tidyverse stringi
#'@param        lgreg: svyglm() object which estimates the propensity of being included in the target data
#'@param        wtdat: output from pseudoweight(); if wtdat=NULL, pseudoweights (ALP and kw) will be generated automatically
#'@param        yy:     the outcome variable name; e.g. yy="had_diabetes"
#'@param        mth:    pseudoweighting methods.  mth='alp' or mth='kw' with the default krnfun dnorm
#'@param        var.PS: logical with the value of "TRUE" accounting for variance due to esitmating the propensity scores
#'@param        by.var: variable name, e.g. by.var="race", subgroup mean estimation. The default value of "NULL"
#'                reports population mean estimates only

#'@return       a data frame with columns of (n, cv.wt, est, se, se.TL), ie.
#'         sample size, cv of the pseudowts, mean estimates of y, standard error without and with accounting for estimating PS

#'@examples
#' data.prpn=exampleData
#' library(dplyr);library(survey);library(tidyverse);library(stringi)
#' data.prpn$y = recode(data.prpn$had_diabetes, "1"=1,  "2"=0, "4"= 0,"3"=0)
#' #---identify and remove strata with 1 psu and observations with missing y values-----------------
#' mis.y= is.na(data.prpn[,"y"])
#' if (sum(mis.y)>0) dat.nhisbrfss = data.prpn[!mis.y| data.prpn$A==0,] #delete observations with missing outcome

#' str.1=which(table(data.prpn$str)==1)
#' if (sum(str.1)>0) dat.nhisbrfss = dat.nhisbrfss[(dat.nhisbrfss$str!=names(str.1)),]   #delete stratum with one psu
#' dim(dat.nhisbrfss)
#'
#' brfss0=dat.nhisbrfss[dat.nhisbrfss$A==1,]; n.brfss0=nrow(brfss0)
#' nhis0 =dat.nhisbrfss[dat.nhisbrfss$A==0,]; n.nhis0=nrow(nhis0)
#' set.seed(10192020); samNHIS0=sample(1:n.nhis0, 5000)
#' dat.nhisbrfss = data.frame(rbind(brfss0,nhis0[samNHIS0,]))
#'
#' x1.var<-c("agegr3","dmsex","dmethnic_y_n","RaceGrp4","metro_stat","regionC4","children3","educ4","employ2")
#' x2.var<-c("health_care_coverage","vaccine","cvd","pulg","immun","had_astma_still")
#' x.var <- c(x1.var, x2.var,'y')
#' ################### DESIGNS of dat.nhisbrfss data ##################################
#' prpn.dsgn.onewt=svydesign(data=dat.nhisbrfss, ids = ~psu, strata = ~str, weights=~wt, nest=TRUE)
#' prpn.dsgn.rawwt=svydesign(data=dat.nhisbrfss, ids = ~psu, strata = ~str, weights=~raw.wt, nest=TRUE) #consider brfss weights in propensity analysis
#' no.dsgn=svydesign(data=dat.nhisbrfss, ids = ~1,  weights=~1)
#' N.popn=sum(nhis0$wt)
#'
#'###################------- construct PS-based weights--------################################
#'#-----model constructon
#' Formula_fit.x = as.formula("A ~ regionC4+agegr3+dmsex+RaceGrp4+dmethnic_y_n+metro_stat+
#'                            children3+educ4+employ2+health_care_coverage+vaccine+cvd+pulg+immun")
#' Formula_fit.x.all = update(Formula_fit.x, ~.^2)
#' lgtreg.obj = svyglm(Formula_fit.x.all,family = binomial, design = prpn.dsgn.onewt)
#'################################
#' dat.wt.x.all = pseudoweights(lgreg = lgtreg.obj,  mth='kw', TD = TRUE)
#' se.est.mean(lgreg = lgtreg.obj, wtdat=dat.wt.x.all, yy="y", mth='kw', var.PS=F, by.var=NULL)
#' se.est.mean(lgreg = lgtreg.obj, wtdat=NULL, yy="y", mth='alp', var.PS=T, by.var="dmsex")
#'
#'@export
#'
se.est.mean<-function(lgreg, wtdat=NULL, yy, mth='kw', var.PS=FALSE, by.var=NULL){
  inpar = lgreg.par(lgreg) #this is a list
  if(is.null(wtdat)) wtdat = pseudoweights(lgreg, mth, var.PS)
  
  wwt_beta=as.matrix(wtdat[,mth]) #kw weights
  pwt = wwt_beta[,1]; quantile(pwt)
  if(ncol(wwt_beta)>1) pwt_beta = wwt_beta[,-1]
  
  ######--------svy package estimates of mean/SE
  n.cmplt = nrow(wtdat); id.subgrp = matrix(rep(1,n.cmplt))
  id.mis=F
  cv.wt = sd(pwt)/mean(pwt)
  if(!is.null(by.var)) {
    id.mis = is.na(wtdat[,by.var])
    n.cat = nlevels(factor(wtdat[,by.var]))
    id.subgrps <- matrix(0,n.cmplt,n.cat)
    id.subgrps[!id.mis,]=model.matrix(as.formula(paste0("~factor(",by.var,")-1")),wtdat)
    cv.wt = c(cv.wt,sapply(1:n.cat, function(i) sd(pwt[id.subgrps[,i]==1])/mean(pwt[id.subgrps[,i]==1])))
    id.subgrp <- cbind(1, id.subgrps) # assign values of zero if byvar = missing
  }
  n.subgrp = apply(id.subgrp,2,sum)

  dsgn.pw <-svydesign(ids=~1, weights = pwt[!id.mis], data=wtdat[!id.mis,])
  est.full = svymean(as.formula(paste0("~",yy)), dsgn.pw, na.rm=T)
  est.full.v = c(est=coef(est.full),se.svy=c(sqrt(diag(vcov(est.full)))))
  
  rslt.svy = c(n.subgrp[1], cv.wt[1], est.full.v)                # full sample estimates
  names(rslt.svy) = c("n", "cv.pwt", "est", "se")
  
  if (!is.null(by.var)) {
    ests.subgrp = svyby(as.formula(paste("~",yy)),by=as.formula(paste0("~",by.var)),dsgn.pw,svymean)
    rslt.svy= data.frame(n=n.subgrp, cv.pwt=cv.wt, rbind(est.full.v, ests.subgrp[,-1]))
    rownames(rslt.svy) = c("full_sample",paste0(by.var, levels(factor(wtdat[,by.var]))))
  }                                                 # subgroup estimates
  rslt = rslt.svy
  
  ##############-------------se.PScr
  if(var.PS==TRUE){
    n.yy = length(est.full);n.grps= length(n.subgrp)
    ests = matrix(sapply(1:n.yy, function (i) 
      apply(wtdat[,yy]*id.subgrp*pwt,2,sum)/apply(id.subgrp*pwt,2,sum)))
    
    v2.TL.mean = NULL
    for (i in 1:n.yy){
      for (g in 1:n.grps){
        tmp= v2_Poisson(pw = pwt*id.subgrp[,g], pw_beta = pwt_beta*id.subgrp[,g],
                        model.par = inpar, mu_hat = ests[g,i], y = wtdat[,yy],)
        v2.TL.mean=rbind(v2.TL.mean, c(tmp$v_all[1,1], tmp$v2stp))
      }
    }
    colnames(v2.TL.mean) = c("se.TL","se.PS2"); rownames(v2.TL.mean)=colnames(id.subgrp)
    if (is.null(by.var))  rslt.mean = c(rslt, sqrt(v2.TL.mean[,1]))#, sqrt(v2.TL.mean[,2]))
    if (!is.null(by.var)) rslt.mean = data.frame(rslt, se.TL=sqrt(v2.TL.mean[,1]))
  }
  return(rslt.mean)
}

#'@title Propensity-based pseudoweighted estimation of logistic regression models
#'@description Propensity-based pseudoweighted estimates and tests of regression coefficients 
#'             with pseudoweights estimated by the inverse of estimated inclusion probabilities method and kernel smoothing methods, denoted by ALP and KW
#'
#'@import stats survey mvtnorm Hmisc dplyr tidyverse stringi
#'@param        lgreg: svyglm() object which estimates the propensity of being included in the target data
#'@param        wtdat: output from pseudoweight(); if wtdat=NULL, pseudoweights (alp and kw) will be generated automatically
#'@param        fm:     fomulus for a logistic regression modeling of a study variable; e.g. fm=as.formula("had_diabetes~age+gender")
#'@param        mth:    PS-based pseudoweighting methods.  mth='alp' or mth='kw' with the default krnfun dnorm
#'
#'@return       a list of three data frames of 
#'         $est: columns of (est, se, pvalue0, se.TL, pvalue), corresponding to the regression coefficient estimates, standard error and pvalue without and with accounting for estimating PS
#'         $vcov: var-cov matrix of regression coefficients without and with accounting for estimating PS
#'         $Gtest: global wald tests for covariates in the regression model

#'@examples
#' data.prpn=exampleData
#' library(dplyr);library(survey)
#' data.prpn$y = recode(data.prpn$had_diabetes, "1"=1,  "2"=0, "4"= 0,"3"=0)
#' #---identify and remove strata with 1 psu and observations with missing y values-----------------
#' mis.y= is.na(data.prpn[,"y"])
#' if (sum(mis.y)>0) dat.nhisbrfss = data.prpn[!mis.y| data.prpn$A==0,] #delete observations with missing outcome

#' str.1=which(table(data.prpn$str)==1)
#' if (sum(str.1)>0) dat.nhisbrfss = dat.nhisbrfss[(dat.nhisbrfss$str!=names(str.1)),]   #delete stratum with one psu
#' dim(dat.nhisbrfss)
#'
#' brfss0=dat.nhisbrfss[dat.nhisbrfss$A==1,]; n.brfss0=nrow(brfss0)
#' nhis0 =dat.nhisbrfss[dat.nhisbrfss$A==0,]; n.nhis0=nrow(nhis0)
#' set.seed(10192020); samNHIS0=sample(1:n.nhis0, 5000)
#' dat.nhisbrfss = data.frame(rbind(brfss0,nhis0[samNHIS0,]))
#'
#' x1.var<-c("agegr3","dmsex","dmethnic_y_n","RaceGrp4","metro_stat","regionC4","children3","educ4","employ2")
#' x2.var<-c("health_care_coverage","vaccine","cvd","pulg","immun","had_astma_still")
#' x.var <- c(x1.var, x2.var,'y')
#' ################### DESIGNS of dat.nhisbrfss data ##################################
#' prpn.dsgn.onewt=svydesign(data=dat.nhisbrfss, ids = ~psu, strata = ~str, weights=~wt, nest=TRUE)
#' prpn.dsgn.rawwt=svydesign(data=dat.nhisbrfss, ids = ~psu, strata = ~str, weights=~raw.wt, nest=TRUE) #consider brfss weights in propensity analysis
#' no.dsgn=svydesign(data=dat.nhisbrfss, ids = ~1,  weights=~1)
#' N.popn=sum(nhis0$wt)
#'
#'###################------- construct PS-based weights--------################################
#'#-----model constructon
#' Formula_fit.x = as.formula("A ~ regionC4+agegr3+dmsex+RaceGrp4+dmethnic_y_n+metro_stat+
#'                            children3+educ4+employ2+health_care_coverage+vaccine+cvd+pulg+immun")
#' Formula_fit.x.all = update(Formula_fit.x, ~.^2)
#' lgtreg.obj = svyglm(Formula_fit.x.all,family = binomial, design = prpn.dsgn.onewt)
#' fm_diab = as.formula("y ~ agegr3 + dmsex + factor(RaceGrp4) + dmethnic_y_n")
#'################################
#' dat.wt.x.all = pseudoweights(lgreg = lgtreg.obj,  mth='kw', TD = TRUE)
#' se.est.reg(lgreg = lgtreg.obj, wtdat=dat.wt.x.all, fm_diab, mth='kw')
#' se.est.reg(lgreg = lgtreg.obj, wtdat=NULL, fm=fm_diab, mth='alp')
#'
#'@export
#'
se.est.reg<-function(lgreg, wtdat=NULL, fm, mth='kw'){
  inpar = lgreg.par(lgreg) #this is a list
  if(is.null(wtdat)) wtdat = pseudoweights(lgreg, mth, )
  
  wwt_beta=as.matrix(wtdat[,mth]) #kw weights
  pwt = wwt_beta[,1]; quantile(pwt)
  if(ncol(wwt_beta)>1) pwt_beta = wwt_beta[,-1]
  
  ######--------svy package estimates of mean/SE
  n.cmplt = nrow(wtdat)
  cv.wt = sd(pwt)/mean(pwt)
  
  dsgn.pw <-svydesign(ids=~1, weights = pwt, data=wtdat)
  glm.yx = svyglm(fm,design = dsgn.pw,family = binomial(link = "logit"))
  v.yx.w0=vcov(glm.yx); design.mat = model.matrix(fm,wtdat)
  covx.names = str_split(gsub(fm, pattern = c('\n    '), replacement  = ""), c(" \\+ "))[[3]]
  tmp.yx = v2_lgtreg(pw= pwt, pw_beta= pwt_beta, glm.yx, model.par= inpar, scF.svy=1)
  v2.TL.reg = tmp.yx$v_all[1:length(glm.yx$coefficients),1:length(glm.yx$coefficients)]#, TL2stg=tmp.yx$v2stp)
  pvalue = 1-2*abs(pnorm(glm.yx$coefficients/sqrt(diag(v2.TL.reg)))-.5)
  
  uid=1;pv.x=pv0.x=NULL
  for (i in 1:length(covx.names)){
  
    df.v=sum(str_detect(pattern = gsub(x=gsub(x=covx.names[i],pattern = c("factor\\("),replacement =""),
                                       pattern="\\)",replacement = ""),names(glm.yx$coefficients)))
    
    lid=uid+1;uid=lid+df.v-1; df.v
    
    wald.stat0=glm.yx$coefficients[lid:uid]%*%solve(v.yx.w0[lid:uid,lid:uid])%*%glm.yx$coefficients[lid:uid]
    tmp0=1-pchisq(wald.stat0,df.v); wald.stat0 #  p.value0 = regTermTest(glm.yx,covx.names[i])$p
    pv0.x=c(pv0.x,tmp0); pv0.x
    wald.stat=glm.yx$coefficients[lid:uid]%*%solve(tmp.yx$v_all[lid:uid,lid:uid])%*%glm.yx$coefficients[lid:uid]
    tmp1=1-pchisq(wald.stat,df.v); wald.stat
    pv.x=c(pv.x,tmp1); pv.x
  } #---global tests for each covariates
  
  est.reg  = data.frame(est=summary(glm.yx)$coefficients[,1],se=summary(glm.yx)$coefficients[,2], pvalue0=summary(glm.yx)$coefficients[,4], se.TL= c(sqrt(diag(v2.TL.reg))), pvalue)
  vcov.reg = data.frame(v0=vcov(glm.yx),TL = v2.TL.reg)
  Gtest.reg= data.frame(Gpvalue0 = pv0.x, Gpvalue = pv.x)
  row.names(Gtest.reg)=covx.names
  
  return(list(est=est.reg, Gtest = Gtest.reg, vcov = vcov.reg))
} # regression analysis 

lgreg.par <- function(lgreg){
  #################################################################################################
  # lgreg.par(): generate noise parameters from the svyglm() analysis as the inputs for se.mean() #
  # Output:      a list of intermediate results such as 
  #              model.par = prpn.params, p.c=p.c, p.s=p.s,
  #              design.x.c=design.x.c, design.x.s=design.x.s,
  #              svy.wt= svy.wt, cht.wt = cht.wt, svy.str = svy.str, svy.psu = svy.psu,
  #              di=di, id=id, n_s= n_s, n_c=n_c, p_score.c=p_score.c, p_score.s=p_score.s,
  #              target.dat=cht0
  #################################################################################################
  dsgn=lgreg$survey.design

  na.id = lgreg$na.action ; length(na.id)
  compl.dat=(lgreg$data)
  if(length(na.id)>0) compl.dat=(lgreg$data)[-na.id,]; dim(compl.dat)

  di=weights(dsgn); length(di)    #original survey and cohort weights
  str = as.factor(dsgn$strata[,1]);length(str)
  psu = as.factor(dsgn$cluster[,1]);length(psu)
  id <- which(lgreg$y==1); length(lgreg$y)     #cohort membership indicator

  n.cmplt= length(di)
  design.x = model.matrix(lgreg)
  bs = lgreg$linear.predictors
  p.hat = lgreg$fitted.values

  design.x.c = design.x[id,]; design.x.s = design.x[-id,]
  p_score.s = bs[-id]; p_score.c = bs[id]
  p.s = p.hat[-id]   ; p.c = p.hat[id]

  cht0 = compl.dat[id,];  svy0 = compl.dat[-id,]; nrow(svy0);nrow(cht0)
  svy.wt = di[-id]; n_s=length(svy.wt);  cht.wt = di[id] ; n_c=length(cht.wt);n_c;n_s
  svy.str = str[-id];  svy.psu = psu[-id]; length(svy.psu)

  gamma = lgreg$coeff; se.gamma=sqrt(diag(lgreg$cov.unscaled));pvalue=1-2*abs(pnorm(gamma/se.gamma)-.5)
  prpn.params = cbind(gamma = gamma, ste.gamma=se.gamma, pvalue = pvalue)

  varEst.inpar = list(model.par = prpn.params, p.c=p.c, p.s=p.s,design.x.c=design.x.c, design.x.s=design.x.s,
                      svy.wt= svy.wt, cht.wt = cht.wt, svy.str = svy.str, svy.psu = svy.psu,
                      di=di, id=id, n_s= n_s, n_c=n_c, p_score.c=p_score.c, p_score.s=p_score.s,
                      target.dat=cht0)

  return(varEst.inpar)
}#end lgreg.par

#'@title create alp and/or kw pseudoweights
#'@param lgreg: svyglm() object which estimates the propensity of being included in the target data
#'@param mth:   pseudoweighting methods.  mth='kw' to generate both alp and kw weights (krnfun=dnorm), or
#'              mth='alp' only generate alp weights
#'@param TD:    logical with default value of TRUE, generating Taylor Deviates for each model parameter
#'@return  the target data appended with the generated pseudoweights and their taylor deviates if TD=True
#'@export
pseudoweights = function(lgreg, mth, TD=TRUE){
  ##########################################################################################################
  # pseudoweights(): create the pseudoweights of alp and/or kw for the target data                         #
  # Input: lgreg: svyglm() object which estimates the propensity of being included in the target data      #
  #        mth:   pseudoweighting methods.  mth='alp' or mth='kw' and the default krnfun is dnorm          #
  #        TD:    logical with default value of TRUE, generating Taylor Deviates for each model parameter  #
  # Output:                                                                                                #
  #        the target data with generated pseudoweights and their taylor deviates if TD=True               #
  ##########################################################################################################
  inpar = lgreg.par(lgreg)

  di=inpar$di; id=inpar$id
  n_s=inpar$n_s; n_c=inpar$n_c;
  p_score.c=inpar$p_score.c; p_score.s=inpar$p_score.s;
  svy.wt=inpar$svy.wt; cht.wt=inpar$cht.wt;
  design.x.s=inpar$design.x.s;design.x.c=inpar$design.x.c

  cht0=inpar$target.dat
  ######--------- ALP weights
    alp <- as.vector(1/exp(p_score.c))*(di[id]) #add *original panel weigts for cohort
    pw_beta = NULL
    if (TD==TRUE) pw_beta = -alp*design.x.c
    cht0$alp = cbind(alp,pw_beta)

  #####======---- kw weights
    kw=pw_beta=NULL
    if(mth=='kw'){
      kw_krnfun=dnorm
      kw = rep(0, n_c);  pw_beta_kw = rep(0, n_c); grp_size = 2000; G=floor(n_s/grp_size)
        # Divide nhis sample into G groups due to large sample size
        if (G<=1) {lw=as.vector(c(1));up=as.vector(c(n_s)); G=1}
        if (G>1)  {up = c(seq(0, n_s, grp_size)[2:G], n_s);lw = seq(1, n_s, grp_size)[-(G+1)]}
        h = bw.nrd0(p_score.c)
        num_unmatch = 0
        for(g in 1:G){
          sgn_dist_mtx.g0 = outer(p_score.s[lw[g]:up[g]], p_score.c, FUN = "-")
          out = krnwt(sgn_dist_mtx.g0, h, svy.wt0=svy.wt[lw[g]:up[g]], cht.wt0=cht.wt, krnfun = kw_krnfun,
                      w_beta=TD, design.x.c0 = design.x.c, design.x.s0= design.x.s[lw[g]:up[g],])
          kw = out$psd.wt+kw
          pw_beta_kw = out$pw_beta+pw_beta_kw
          num_unmatch = out$sum_0.s+num_unmatch

          if (g%%15==0) print(paste0(g," out of ", G, " iterations have been completed"))
        }
      if (num_unmatch>0) warning(paste0(num_unmatch,' out of ', n_s, ' survey units are not matched to any of the target data'))

      if (TD==TRUE) pw_beta=pw_beta_kw
      cht0$kw = cbind(kw,pw_beta)
    }#end kw weights
  return(cht0)
}

# krnwt(sgn_dist_mtx.g0, h, svy.wt0=svy.wt[lw[g]:up[g]], cht.wt0=cht.wt, krnfun = kw_krnfun,      w_beta=TD, design.x.c0 = design.x.c, design.x.s0= design.x.s[lw[g]:up[g],])

krnwt <- function(sgn_dist_mtx.g, h, svy.wt0, cht.wt0, krnfun, w_beta=F,design.x.c0, design.x.s0){
  
  #####################################################################################
  # FUNCION krnwt is function to calculate KW weights and the derivative              #
  #         w.r.t. beta given the distance matrix                                     #
  # INPUT                                                                             #
  #  sgn_dist_mtx: distance matrix (row for survey, column for cohort.                #
  #  h:            bandwidth                                                          #
  #  svy.wt0:       vector of survey sample weight                                     #
  #  cht.wt0:       vector of cohort sample weight                                     #
  #  krnfun:       kernel function                                                    #
  #  w_beta:       Whether caculate derivative (default is FALSE)                     #
  #  design.x.c:   Design matrix for cohort if w_beta =T (NULL)                       #
  #  design.x.s:   Design matrix for survey if w_beta =T (NULL)                       #
  # OUTPUT                                                                            #
  #  psd.wt:       KW pseudo weights                                                  #
  #  pw_beta:       partial derivative of pw w.r.t propensity model                   #
  #                 coefficients beta                                                 #
  #  sum_0.s:       number of unmatched survey sample units                           #
  #####################################################################################

  # Get size of cohort and survey sample
  n_c = ncol(sgn_dist_mtx.g); n_s = nrow(sgn_dist_mtx.g)
  krn_num = krnfun(sgn_dist_mtx.g/h)  # K[{p^(s)_j- p^(s)_j}/h]

  krn_num[krn_num<dnorm(10)] = 0       # treated as unmatched pair

  krn_num = t(t(krn_num)*cht.wt0)     # Multiply each row by the cht.wt

  row.krn = rowSums(krn_num);         # sum_i\in s_c [K[{p^(s)_j- p^(s)_j}/h]]
                                      # Check if there are unmatched survey sample units
  sum_0.s = (row.krn==0);# sum(sum_0.s)    ###########------set up a cutoff value

  if(sum(sum_0.s)>0){
    id.unmtch = as.vector(which(sum_0.s));
    n_s=n_s-length(id.unmtch);
    krn_num=krn_num[-id.unmtch,];
    row.krn=rowSums(krn_num);
    svy.wt0=svy.wt0[-id.unmtch];
    design.x.s0=design.x.s0[-id.unmtch,];
    sgn_dist_mtx.g=sgn_dist_mtx.g[-id.unmtch,];
    warning(paste(sum(sum_0.s), "records in the survey sample were not used because of a small bandwidth"))
  }
  ################------if rm.s=T, there is a bug here that row.krn=rowSums(krn_num) should not be run and therefore deleted###########
  krn=krn_num/row.krn
                        # Final psuedo weights
  pswt_mtx = krn*svy.wt0; psd.wt = colSums(pswt_mtx)
                        # Take derivative of the psuedo weights w.r.t. beta
  pw_beta = NULL

  if(w_beta){
    if (is.null(design.x.c0)|is.null(design.x.s0)) stop("Need design matrix to calculate derivative of weights wrt beta")
    n.beta = dim(design.x.c0)[2]
    pw_beta=matrix(0, n_c, n.beta)
    for(i in 2:n.beta){
      design.x.dist=outer(design.x.s0[,i], design.x.c0[,i], FUN="-")
      kij_beta = -krn_num*sgn_dist_mtx.g*design.x.dist/h/h
      row.kij_beta = rowSums(kij_beta);
      deriv1= (svy.wt0/row.krn)%*%kij_beta
      deriv2= -(svy.wt0*row.kij_beta/row.krn/row.krn)%*%krn_num  ############-----row.krn^2 can cause zero denominator;  one by one will work
      pw_beta[,i] = deriv1+deriv2
      #if(i%%10==0) print(paste0(i,' ',mean(pw_beta[,i])))
    }
  }#end w_beta
  return(list(psd.wt = psd.wt, pw_beta = pw_beta,
              sum_0.s = sum(sum_0.s)))
} # end FUNCTION krnwt

var.TL.cmplx<-function(wtVars, svy.strata=NULL, svy.psu=NULL){
  #wtVars=Phi_2; svy.strata= sstrata; svy.psu= spsu
  #############################################################################################
  #-FUNCTION var.TL.cmplx is to compute variance of totals of weighted variables,             #
  #                 considering designs of weights, stratification or clustering              #
  # INPUT:  wtVars- matrix of one or multiple wted variables of n.s by p, such as wtTD        #
  #         svy.strata -  vector of  stratum IDs corresponding to each observation            #
  #         svy.psu    -  vector of  cluster IDs corresponding to each observation            #                                             #
  # OUTPUT: variance covairance matrix of total of wtVars, p by p matrix                      #
  #                                                             #
  #############################################################################################
  n_s = dim(wtVars)[1]
  if(is.null(svy.psu)&is.null(svy.strata))
    {v2 = var(wtVars)*n_s}                  #SRS
  if(!is.null(svy.psu) | !is.null(svy.strata)){
    if(is.null(svy.psu)) {                      #SSRS
      n.psu_st=table(svy.strata)
      wtVars_psutot = wtVars
      psutot_strtID = svy.strata
      st.psu.1  = names(which(n.psu_st<2))       #identify stratum with one observation
      st.del.id = which(svy.strata%in%st.psu.1)
      if(length(st.del.id)>0)  # there is  delete strata
        { wtVars_psutot = wtVars[-st.del.id,]
          psutot_strtID = svy.strata[-st.del.id]}
      }#end SSRS
    if(!is.null(svy.psu)){                      #Strata & cluster
      psutot = aggregate(wtVars, by = list(svy.psu, svy.strata), FUN=sum)
      n.psu_st = table(psutot[,2])
      wtVars_psutot = as.matrix(psutot[,-c(1,2)])
      psutot_strtID = psutot[,2]  #sorted by psu and strata in aggregate()

      st.psu.1  = names(which(n.psu_st<2))       #identify strata with one psu
      st.del.id = which(psutot[,2]%in%st.psu.1)
      if(length(st.del.id)>0){                 #there are such strata, delete
        wtVars_psutot = wtVars_psutot[-st.del.id,]
        psutot_strtID = psutot_strtID[-st.del.id]
        }
      }
    n.strata= length(unique(svy.strata))-length(st.psu.1)
    #strata.names0 = unique(svy.strata) #####unsorted, same as original input
    strata.names0 = as.numeric(names(n.psu_st))
    strata.names = strata.names0[!(strata.names0%in%st.psu.1)]

    for(l in 1: n.strata){
      n.psu_l = which(psutot_strtID == strata.names[l])
      wtVars_psutot.l = as.matrix(wtVars_psutot)[n.psu_l,]
      v2.l = var(wtVars_psutot.l)*length(n.psu_l)

      #wtVars_psutot.l = wtVars_psutot[(psutot_strtID == strata.names[l]),]
      #v2.l = var(wtVars_psutot.l)*n.psu_st[l]

      if(l==1) v2 = v2.l
      if(l>1) v2=v2+v2.l
      v2;l=l+1}
  }
  v2
}

v2_Poisson <- function(pw, pw_beta, mu_hat, model.par, y, scF.svy=1){
  #########################################################################################
  # FUNCTION v2_Poisson is a function for TL variance of                                  #
  #             pseudoweigthed sample mean, accounting for variance of beta               #
  #             assuming cohort is poisson sampling and svy is SRS, SSRS, or CS           #
  # INPUT                                                                                 #
  #  pw:         pseudo-weight                                                            #
  #  pw_beta:    partial derivative of pw w.r.t propensity model coefficients             #
  #  mu_hat:     estimate of finite population mean                                       #
  #  model.par:  a list including estimated PS and design matrix for cohort               #
  #              and survey sample                                                        #
  #  y:          vector of study variable for its popualtion mean estimation              #
  # OUTPUT                                                                                #
  #  v_all:      variance matrix of the mean + propensity model coefficients              #
  #  v2stp:      variaince of esitmated pseduoweighted mean                               #
  #########################################################################################
  sstrata=model.par$svy.str;spsu=model.par$svy.psu
  svy.wt=model.par$svy.wt;cht.wt=model.par$cht.wt

  p.c = model.par$p.c
  p.s = model.par$p.s
  design.x.c = model.par$design.x.c
  design.x.s = model.par$design.x.s
  pi.c = p.c/(1-p.c)                                       # requiring that pi.c<1  under ALP model, pi is odds
  n_c = length(p.c); n_s = length(p.s)

  U_mu   = -sum(pw)
  U_beta = c(y-mu_hat)%*%pw_beta
  S_mu   = rep(0, dim(pw_beta)[2])
  S_beta = -t(cht.wt*p.c*(1-p.c)*design.x.c)%*%design.x.c-  ######add cht.wt*
    t(svy.wt* p.s*(1-p.s)*design.x.s)%*%design.x.s

  S_beta_inv = solve(S_beta)
  b=-1/U_mu*U_beta%*%S_beta_inv
  phi_inv = rbind(c(1/U_mu, b),
                  cbind(S_mu, S_beta_inv))

  # Calculate var(Phi)
  Phi_1  = as.matrix(cbind(pw*(y-mu_hat), cht.wt*(1-p.c)*design.x.c)) #####add cht.wt*
  Phi_2  = -as.matrix(cbind(0, svy.wt* p.s*design.x.s))

  v1.psn = t(Phi_1)%*%(Phi_1*(1-c(pi.c)/c(cht.wt)*scF.svy)) ##### Assuming Poisson sampling for cohort sample divided by cht.wt
  v2.psn = t(Phi_2)%*%(Phi_2*(1-scF.svy/c(svy.wt)))         ##### Assuming Poisson sampling for survey sample
  ####1/svy.wt is not sel prob for scaled weights
  as.vector(diag(v1.psn))[1:10];as.vector(diag(v2.psn))[1:10]
  #------using svytotal to accont for survey design of Phi_1-----------------
  # str.del = names(which(table(sstrata)<2)); idd=which(sstrata==str.del)
  # new.obj = svydesign(ids=~1, strata=sstrata[-idd], weights=~1, data=data.frame(svy.wt*p.s*design.x.s)[-idd,])
  # v2=svytotal(new.obj$variables, design=new.obj)
  # diag(vcov(v2))

  v1 <- var(Phi_1)*n_c                    # For cohort data, assume SRS sampling
                                          # For survey data, assume complex sampling
  o=order(as.vector(sstrata),as.vector(spsu))  ###### sort the data by strata and psu, same results
  v2 <- var.TL.cmplx(Phi_2[o,], sstrata[o], spsu[o])

  v_Phi = v1+v2                           # assume SRS for nonprob sampling
  v_all = phi_inv%*%v_Phi%*%t(phi_inv)

  v2stp.1 = var(pw*(y-mu_hat))*n_c/U_mu^2  # assume SRS for cohort sampling
  v2stp.2 = U_beta%*%v_all[-1, -1]%*%t(U_beta)/U_mu^2
  v2stp = v2stp.1+v2stp.2
  return(list(v_all=v_all, v2stp=v2stp))
} # End Sandwitch var

v2_lgtreg <- function(pw, pw_beta, glm.yx, model.par, scF.svy=1){
  #########################################################################################
  # FUNCTION v2_lgtreg is a function for TL variance of estimated                         #
  #             pseudoweigthed logit-regressin coef, accounting for variance of beta      #
  #             assuming nonprob sample is srs sampling and svy is SRS, SSRS, or CS       #
  # INPUT                                                                                 #
  #  pw:         pseudo-weight                                                            #
  #  pw_beta:    partial derivative of pw w.r.t propensity model coefficients             #
  #  mu_hat:     estimate of finite population mean                                       #
  #  model.par:  a list including estimated PS and design matrix for cohort               #
  #              and survey sample                                                        #
  #  y:          vector of study variable for its popualtion mean estimation              #
  # OUTPUT                                                                                #
  #  v_all:      variance matrix of the mean + propensity model coefficients              #
  #  v2stp:      variaince of esitmated pseduoweighted mean                               #
  #########################################################################################
  sstrata=model.par$svy.str;spsu=model.par$svy.psu
  svy.wt=model.par$svy.wt;cht.wt=model.par$cht.wt
  
  mu_hat= glm.yx$fitted.values
  design.x.y=model.matrix(glm.yx)
  y=glm.yx$y
  nx.param = ncol(design.x.y)
    
  p.c = model.par$p.c
  p.s = model.par$p.s
  design.x.c = model.par$design.x.c
  design.x.s = model.par$design.x.s
  pi.c = p.c/(1-p.c)                                       # requiring that pi.c<1  under ALP model, pi is odds
  n_c = length(p.c); n_s = length(p.s)
  
  # design.x.y=cbind(1,glm.x1x2x3$data[glm.x1x2x3$data$id==1,"x3.cat"])
  
  U_gamma  = -t(design.x.y)%*%diag(pw*mu_hat*(1-mu_hat))%*%design.x.y
  U_beta = t(design.x.y)%*%diag(y-mu_hat)%*%pw_beta
  S_gamma   = matrix(0,dim(pw_beta)[2], nx.param)
  S_beta = -t(cht.wt*p.c*(1-p.c)*design.x.c)%*%design.x.c-  ######add cht.wt*
    t(svy.wt* p.s*(1-p.s)*design.x.s)%*%design.x.s
  
  S_beta_inv = solve(S_beta)
  b=solve(U_gamma)%*%(U_beta)%*%S_beta_inv
  phi_inv = rbind(cbind(solve(U_gamma), b),
                  cbind(S_gamma, S_beta_inv))
  
  # Calculate var(Phi)
  Phi_1  = as.matrix(cbind(pw*(y-mu_hat)*design.x.y, cht.wt*(1-p.c)*design.x.c)) #####add cht.wt*
  Phi_2  = -as.matrix(cbind(matrix(0,n_s,nx.param),svy.wt* p.s*design.x.s)); 
  
  v1.psn = t(Phi_1)%*%(Phi_1*(1-c(pi.c)/c(cht.wt)*scF.svy)) ##### Assuming Poisson sampling for cohort sample divided by cht.wt
  v2.psn = t(Phi_2)%*%(Phi_2*(1-scF.svy/c(svy.wt)))         ##### Assuming Poisson sampling for survey sample
  ####1/svy.wt is not sel prob for scaled weights
  as.vector(diag(v1.psn));as.vector(diag(v2.psn))

  v1 <- var(Phi_1)*n_c                    # For cohort data, assume SRS sampling
  # For survey data, assume complex sampling
  o=order(as.vector(sstrata),as.vector(spsu))  ###### sort the data by strata and psu, same results
  v2 <- var.TL.cmplx(Phi_2[o,], sstrata[o], spsu[o])
  
  v_Phi = v1+v2                           # assume SRS for nonprob sampling
  v_all = phi_inv%*%v_Phi%*%t(phi_inv)
  
  v2stp.1 = solve(U_gamma)%*%(var(pw*(y-mu_hat)*design.x.y)*n_c)%*%solve(U_gamma)  # assume SRS for cohort sampling
  v2stp.2 = solve(U_gamma)%*%(U_beta%*%v_all[-c(1:nx.param), -c(1:nx.param)]%*%t(U_beta))%*%solve(U_gamma)
  v2stp = v2stp.1+v2stp.2 #v_all[1:nx.param,1:nx.param]; v2stp
  return(list(v_all=v_all, v2stp=v2stp))
} # End Sandwitch var
####################################################################
#                  Kernel Functions                                #
####################################################################
# triangular density on (-3, 3)
triang = function(x){
  x[abs(x)>3]=3
  1/3-abs(x)/3^2
}
attributes(triang) = list(name = "triang")
# triangular density on (-2.5, 2.5)
triang_2 = function(x){
  x[abs(x)>2.5]=2.5
  1/2.5-abs(x)/2.5^2
}
attributes(triang_2) = list(name = "triang_2")

# N(0, 1)
dnorm_1 = function(x) dnorm(x)
attributes(dnorm_1) = list(name = "dnorm")
# N(0, 3)
dnorm_3 = function(x) dnorm(x, sd=3)
attributes(dnorm_3) = list(name = "dnorm_3")
# standard normal density truncated at -3, and 3
dnorm_t = function(x){
  c = integrate(dnorm, -3, 3)$value
  y=dnorm(x)/c
  y[y<=dnorm(3)/c]=0
  y
}

sidebyside <- function(..., width=60){
  #print list()'s simultaniously
  l <- list(...)
  p <- lapply(l, function(x){
    xx <- capture.output(print(x, width=width))
    xx <- gsub("\"", "", xx)
    format(xx, justify="left", width=width)
  }
  )
  p <- do.call(cbind, p)
  sapply(seq_len(nrow(p)), function(x)paste(p[x, ], collapse=""))
}


